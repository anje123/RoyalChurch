@extends('layouts.app')

@section('content')

    <div class="panel panel-default">
        <div class="panel-heading">Dashboard</div>

        <div class="panel-body">

            <ul class="list-group">
                <li class="list-group-item">
                        You are logged in!
                </li>
             </ul>    
             
             <ul class="list-group">
                 <li class="list-group-item">
Explore
                 </li>
             </ul>
            </div> 
    </div>

       
</div>
@endsection
