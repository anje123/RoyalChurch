<?php $__env->startSection('content'); ?>

  <!-- Inner-intro -->
  <section class="sa-page-title text-left">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   <h1>About Us</h1>
                </div>
                <div class="col-md-12">
                    <nav class="breadcrumb">
                      <ul>
                        <li class="breadcrumb-item"><a>Home</a></li>
                        <li class="breadcrumb-item active">About US</li>
                      </ul>
                    </nav>
                </div>
            </div>
        </div>
    </section>
    <!-- /Inner-intro -->

<!-- About-us -->
<section class="section-padding">
    <div class="container">
        <div class="about_us">
            <div class="section-header text-center">
                <h2>Psalm 34:8-10</h2>
            </div>
            <p><i>  Taste and see that the Lord is good;
                blessed is the one who takes refuge in him.
            
            Fear the Lord, you his holy people,
                for those who fear him lack nothing.
             
            The lions may grow weak and hungry,
                but those who seek the Lord lack no good thing. </i> </p>
        </div>
        <!-- Features -->
        <div class="features">
            <div class="row">
                <div class="col-md-4">
                    <div class="features_wrap">
                        <div class="f__icon"><i class="fa fa-flag"></i></div>
                        <h6>Digging Deep (Tuesday)</h6>
                        <p>(6.30pm - 8.00pm)</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="features_wrap">
                        <div class="f__icon"><i class="fa fa-users"></i></div>
                        <h6>Faith Clinic (Thursday)</h6>
                        <p>(6.30pm - 8.00pm)</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="features_wrap">
                        <div class="f__icon"><i class="fa fa-book"></i></div>
                        <h6>Sunday Service (Sunday)</h6>
                        <p>(7.00 & 8.00am & 10.00am)</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Features -->

       
    </div>

    <!-- Testimonials -->
    <section class="our_testimonials">
        <div class="container">
           <div class="row">
                <div class="col-md-5">
                        <div class="about_company margin_60">
                            <h4 style="padding-left:25px;">Our History</h4>
                            <p style="padding-left:25px;">In July 1909, a son was born into the Akindayomi family of Ondo State of Nigeria. Even though this child grew up surrounded by idol worshippers ...</p>
                            <a style="padding-left:25px;" target="_blank" href="http://rccg.org/who-we-are/history/" class="btn-link"><u>Learn More <i class="fa fa-caret-right"></i></u></a>
                        </div>
                        <div class="about_company" >
                            <h4 style="padding-left:25px;">Mission</h4>
                              <ul>
                                  <li>To make heaven.</li>
                                  <li>To take as many people with us.</li>
                                  <li>To have a member of RCCG in every family of all nations.S</li>
                              </ul>
                            <a style="padding-left:25px;" href="http://rccg.org/who-we-are/mission-and-vision/" target="_blank" class="btn-link"><u>Learn More <i class="fa fa-caret-right"></i></u></a>
                        </div>
                    </div>
               <div class="col-md-7">
                   <div class="img_wrap">

                       <img src="<?php echo e(asset('app/images/IMG_8303.jpg')); ?>" alt="image">
                   </div>
                   <div id="testimonials">
                       <div class="owl-carousel">
                           <div class="item">
                               <p><i> Sing unto the LORD, praise ye the LORD for he hath
                                    delivered the soul of the poor from the hand of evildoers </i> </p>
                               <h6>Jeremiah 20:13</h6>
                               </div>
                       </div>
                   </div>
               </div>
           </div>
        </div>
   </section>
   <!-- /Testimonials -->


    <div class="container">
        <!-- Team -->
        <div class="our_team">
            <div class="section-header text-center">
            </div>
            <div class="row">
            
                <div class="col-12">
                    <div class="box_wrap">
                        <div class="team_img">
                            <img src="<?php echo e(asset('app/images/olutunji.jpg')); ?>" alt="image">
                            <div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
                        </div>
                        <div class="icon"><img src="<?php echo e(asset('app/images/icon.png')); ?>" alt="image"></div>
                        <h6>Pastor Oladimeji Olutunji</h6>
                        <p>Lead Pastor</p>
                    </div>
                </div>
            </div>
            <div class="text-center margin-top-10">
                <a href="/event" class="btn btn-lg dark-btn">Explore Events</a>
            </div>
        </div>
        <!-- /Team -->
    </div>
</section>
<!-- /About-us -->

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>