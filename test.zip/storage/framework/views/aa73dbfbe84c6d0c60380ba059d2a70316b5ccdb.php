<?php $__env->startSection('content'); ?>
    <!-- Inner-intro -->
    <section class="sa-page-title text-left">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                       <h1>Our Events</h1>
                    </div>
                    <div class="col-md-12">
                        <nav class="breadcrumb">
                          <ul>
                            <li class="breadcrumb-item">Home</li>
                            <li class="breadcrumb-item active">Our Events</li>
                          </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </section>
        <!-- /Inner-intro -->
    
    <!-- Events -->
    <section class="section-padding">
        <div class="container">
            <!-- Events-1 -->
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                
                <div class="events_wrap">
                    <div class="event_date">
                        <span><?php echo e($event->date); ?></span> <?php echo e($event->month); ?>'<?php echo e($event->year); ?>

                    </div>
                    <div class="event_img">
                        <a href="#"><img src="<?php echo e(asset($event->event_image)); ?>" alt="image"></a>
                    </div>
                    <div class="event_info">
                        <h4><a href="#"><?php echo e($event->name); ?></a></h4>
                        <p><?php echo e($event->note); ?></p>
                        <ul>
                            <li><i class="fa fa-clock-o"></i> <?php echo e($event->time); ?></li>
                            <li><i class="fa fa-map-marker"></i> <?php echo e($event->venue); ?></li>
                        </ul>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

            <!-- /Events-1 -->
    
        </div>
    </section>
    <!-- /Events -->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>