<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.includes.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="panel panel-default">
        <div class="panel-heading">
    Update Sermon
        </div>

        <div class="panel-body">
        <form action="<?php echo e(route('sermon.update',['id' => $sermon->id])); ?>" method="post" enctype="multipart/form-data">

                 <?php echo e(csrf_field()); ?>

                 <?php echo e(method_field('PUT')); ?>


                <div class="form-group">
                    <label for="venue">Topic</label>
                    <input type="text" class="form-control" value="<?php echo e($sermon->topic); ?>" name="topic" id="">
                </div>

                <div class="form-group">
                    <label for="date">Pastor's Name</label>
                    <input type="text" class="form-control" value="<?php echo e($sermon->pastor); ?>" name="pastor" id="">
                </div>

                <div class="form-group">
                    <label for="image">Programs Image</label>
                    <input type="file" class="form-control" value="<?php echo e($sermon->image); ?>" name="sermon_image" id="">
                </div>
                <div class="form-group">
                    <label for="Month">Month</label>
                    <input type="text" class="form-control" value="<?php echo e($sermon->month); ?>" name="month" id="">
                </div>

                <div class="form-group">
                    <label for="Year">Year</label>
                    <input type="text" class="form-control" value="<?php echo e($sermon->year); ?>" name="year" id="">
                </div>

                <div class="form-group">
                    <label for="time">Date</label>
                    <input type="text" class="form-control" value="<?php echo e($sermon->date); ?>" name="date" id="">
                </div>

                <div class="form-group">
                    <label for="youtube_url">Youtube URL</label>
                    <input type="text" class="form-control" value="<?php echo e($sermon->youtube_url); ?>" name="youtube_url">
                </div>

    
                <div class="form-group">
                    <button class="form-control btn btn-success btn-xs" type="submit">SUBMIT</button>
                </div>

                
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>