<?php $__env->startSection('content'); ?>



<?php echo $__env->make('admin.includes.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="panel panel-default">
        <div class="panel-heading">
    Create An Event
        </div>

        <div class="panel-body">
            
        <form action="<?php echo e(route('event.update',['id' => $event->id])); ?>" method="post" enctype="multipart/form-data">

                 <?php echo e(csrf_field()); ?>

                 <?php echo e(method_field('PUT')); ?>

                <div class="form-group">
                    <label for="name">Name</label>
                    <h6>Please include Venue at the end of the name</h6>
                    <h6 for="" class="pull-right">eg .  CHURCH EASTER CAMP OUT @ Redemption Camp</h6>
                <input type="text" class="form-control"  value="<?php echo e($event->name); ?>" name="name" id="">
                </div>


                <div class="form-group">
                    <label for="date">Day</label>
                    <input type="text" class="form-control" value="<?php echo e($event->date); ?>" name="date" id="">
                </div>

                <div class="form-group">
                    <label for="Month">Month</label>
                    <input type="text" class="form-control" value="<?php echo e($event->month); ?>" name="month" id="">
                </div>

                <div class="form-group">
                    <label for="Year">Year</label>
                    <input type="text" class="form-control" value="<?php echo e($event->year); ?>" name="year" id="">
                </div>

                <div class="form-group">
                    <label for="time">Time</label>
                    <input type="text" class="form-control" value="<?php echo e($event->time); ?>" name="time" id="">
                </div>


                <div class="form-group">
                    <button class="form-control btn btn-success btn-xs" type="submit">SUBMIT</button>
                </div>

                
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>