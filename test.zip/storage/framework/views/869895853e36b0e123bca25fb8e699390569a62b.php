<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.includes.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="panel panel-default">
        <div class="panel-heading">
    Create An Sermon
        </div>

        <div class="panel-body">
        <form action="<?php echo e(route('sermon.store')); ?>" method="post" enctype="multipart/form-data">

                 <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <label for="venue">Sermon's Topic</label>
                    <input type="text" class="form-control" value="<?php echo e(old('topic')); ?>" name="topic" id="">
                </div>

                <div class="form-group">
                    <label for="date">Pastor's Name</label>
                    <input type="text" class="form-control" value="<?php echo e(old('pastor')); ?>" name="pastor" id="">
                </div>

                <div class="form-group">
                    <label for="image">Programs Image</label>
                    <input type="file" class="form-control" value="<?php echo e(old('image')); ?>" name="sermon_image" id="">
                </div>
                <div class="form-group">
                    <label for="Month">Month</label>
                    <h6 for="" class="pull-right">eg. Aug</h6>
                    <input type="text" class="form-control" value="<?php echo e(old('month')); ?>" name="month" id="">
                </div>

                <div class="form-group">
                    <label for="Year">Year</label>
                    <h6 for="" class="pull-right">eg. 19</h6>
                    <input type="text" class="form-control" value="<?php echo e(old('year')); ?>" name="year" id="">
                </div>

                <div class="form-group">
                    <label for="time">Date</label>
                    <h6 for="" class="pull-right">eg 20.</h6>
                    <input type="text" class="form-control" value="<?php echo e(old('date')); ?>" name="date" id="">
                </div>

                <div class="form-group">
                    <label for="youtube_url">Youtube URL</label>
                    <h6 class="pull-right">eg. http://youtube.com/</h6>
                    <input type="text" class="form-control" value="<?php echo e(old('youtube_url')); ?>" name="youtube_url">
                </div>

    
                <div class="form-group">
                    <button class="form-control btn btn-success btn-xs" type="submit">SUBMIT</button>
                </div>

                
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>