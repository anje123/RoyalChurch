<?php $__env->startSection('content'); ?>

 <!-- Inner-intro -->
 <section class="sa-page-title text-left">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   <h1>Sermons</h1>
                </div>
                <div class="col-md-12">
                    <nav class="breadcrumb">
                      <ul>
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item active">Sermons</li>
                      </ul>
                    </nav>
                </div>
            </div>
        </div>
    </section>
    <!-- /Inner-intro -->

<!-- Sermons -->
<section class="section-padding">
	<div class="container">
        <!-- Sermons-list-1 -->
        <?php $__currentLoopData = $sermons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sermon): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            
    	<div class="sermons_wrap">
        	<div class="sermons_img">
            	<a><img src="<?php echo e(asset($sermon->image)); ?>" alt="image"></a>
            </div>
            <div class="sermons_info_wrap">
                <div class="sermons_info">
                    <h5><a href="#"><?php echo e($sermon->topic); ?></a></h5>
                    <ul class="sermons_meta">
                        <li><i class="fa fa-user"></i> Message from <?php echo e($sermon->pastor); ?> </li>
                        <li><i class="fa fa-calendar-check-o"></i> <?php echo e($sermon->month); ?> <?php echo e($sermon->date); ?>, <?php echo e($sermon->year); ?></li>
                    </ul>
                </div>
                <div class="sermons_inside">
                	<ul>
                    <li><a href="<?php echo e($sermon->youtube_url); ?>" target="_blank"><i class="fa fa-youtube-play"></i></a></li>
                        
                    </ul>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <!-- /Sermons-list-1 -->

      
    </div>
</section>
<!-- /Sermons -->


    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>